import { createContext } from "react";

export const Visiblity = createContext(false)