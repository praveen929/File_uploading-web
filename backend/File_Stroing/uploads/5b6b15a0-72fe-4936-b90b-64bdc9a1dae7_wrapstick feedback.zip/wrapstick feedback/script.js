document.addEventListener("DOMContentLoaded", function() {
    document.addEventListener("DOMContentLoaded", function () {
        const starContainer = document.getElementById('star-rating');
        const stars = 5;
        let currentRating = 0;
    
        for (let i = 1; i <= stars; i++) {
            const star = document.createElement('span');
            star.classList.add('cursor-pointer', 'text-gray-400', 'text-3xl');
            star.innerHTML = '&#9733;';
            star.setAttribute('data-value', i);
            starContainer.appendChild(star);
    
            star.addEventListener('mouseover', onMouseOver);
            star.addEventListener('mouseout', onMouseOut);
            star.addEventListener('click', onClick);
        }
    
        function onMouseOver(e) {
            const value = e.target.getAttribute('data-value');
            highlightStars(value);
        }
    
        function onMouseOut() {
            highlightStars(currentRating);
        }
    
        function onClick(e) {
            currentRating = e.target.getAttribute('data-value');
            highlightStars(currentRating);
        }
    
        function highlightStars(value) {
            const stars = starContainer.children;
            for (let i = 0; i < stars.length; i++) {
                if (i < value) {
                    stars[i].classList.add('text-yellow-400');
                    stars[i].classList.remove('text-gray-400');
                } else {
                    stars[i].classList.add('text-gray-400');
                    stars[i].classList.remove('text-yellow-400');
                }
            }
        }
});




});
